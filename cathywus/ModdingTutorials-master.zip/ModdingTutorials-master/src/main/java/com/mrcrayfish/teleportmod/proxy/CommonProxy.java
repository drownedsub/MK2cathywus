package com.mrcrayfish.teleportmod.proxy;

public class CommonProxy {
	public void registerRenders() {

	}
}
